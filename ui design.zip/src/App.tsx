import { useRef, useState } from 'react'

const assetPathPrefix = '/assets'

function Icon({ name, size = 22 }: { name: 'upload' | 'link' | 'arrow' | 'film' | 'check'; size?: number }) {
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
    {name === 'upload' && <><path d="M12 16V3m-5 5 5-5 5 5" /><path d="M4 15v5h16v-5" /></>}
    {name === 'link' && <><path d="m10 13 4-4" /><path d="M8 16 6 18a4 4 0 0 1-6-6l5-5a4 4 0 0 1 6 0m2 1 2-2a4 4 0 0 1 6 6l-5 5a4 4 0 0 1-6 0" transform="translate(1 0)" /></>}
    {name === 'arrow' && <path d="M4 12h16m-6-6 6 6-6 6" />}
    {name === 'film' && <><rect x="3" y="4" width="18" height="16" rx="2" /><path d="M7 4v16M17 4v16M3 9h4m-4 6h4m10-6h4m-4 6h4" /></>}
    {name === 'check' && <path d="m5 12 4 4L19 6" />}
  </svg>
}

export default function App() {
  const [files, setFiles] = useState<File[]>([])
  const [link, setLink] = useState('')
  const [duration, setDuration] = useState(90)
  const [count, setCount] = useState(15)
  const [quality, setQuality] = useState('1080p')
  const [dragging, setDragging] = useState(false)
  const [message, setMessage] = useState('')
  const input = useRef<HTMLInputElement>(null)

  function addFiles(incoming: File[]) {
    const videos = incoming.filter(file => file.type.startsWith('video/') || /\.(mp4|mov|mkv|webm)$/i.test(file.name))
    setFiles(videos)
    setMessage(videos.length ? '' : 'Choose a video file: MP4, MOV, MKV, or WEBM.')
  }

  function analyze() {
    if (!files.length && !link.trim()) return setMessage('Add a local video or paste a YouTube / Twitch link to get started.')
    if (link.trim()) {
      try {
        const url = new URL(link)
        if (!['youtube.com', 'www.youtube.com', 'm.youtube.com', 'youtu.be', 'twitch.tv', 'www.twitch.tv'].includes(url.hostname)) throw new Error()
      } catch {
        return setMessage('Please enter a valid YouTube or Twitch URL.')
      }
    }
    setMessage(`Your source is ready · ${count} clips · ${duration}s · ${quality}. Video analysis requires a connected processing service.`)
  }

  return (
    <div className="app-shell">
      <div className="top-rule"><span>INDEPENDENT TOOLS. LIMITLESS CREATIVITY.</span><span>EST. 2025 / V.01</span></div>
      <main>
        <header className="hero">
          <div className="hero-meta"><span className="status-dot" /> BUILT FOR THE GOOD PARTS</div>
          <div className="brand"><span className="brand-script">Clip</span><span className="brand-serif">Forge</span><span className="brand-star" aria-hidden="true">✳</span></div>
          <div className="hero-bottom"><p>Your one click clipping tool</p><span className="creator">created by <strong>Sueno</strong></span></div>
          <span className="hero-note">Less footage.<br />More fire.</span>
        </header>

        <div className="section-divider"><span>01 / ADD YOUR FOOTAGE</span><span>YOUR NEXT GREAT CLIP STARTS HERE <Icon name="arrow" size={15} /></span></div>
        <section className="source-grid" aria-label="Video sources">
          <article className="source-card">
            <div className="card-heading"><h2>Import Local Clips Here</h2><span className="tiny-tag">LOCAL</span></div>
            <button type="button" className={`drop-zone ${dragging ? 'dragging' : ''}`} onClick={() => input.current?.click()} onDragOver={e => { e.preventDefault(); setDragging(true) }} onDragLeave={() => setDragging(false)} onDrop={e => { e.preventDefault(); setDragging(false); addFiles(Array.from(e.dataTransfer.files)) }}>
              <span className="upload-icon"><Icon name={files.length ? 'check' : 'upload'} size={29} /></span>
              <strong>{files.length ? `${files.length} video${files.length > 1 ? 's' : ''} selected` : 'Drop your footage here'}</strong>
              <span>{files.length ? files.map(file => file.name).join(', ') : <>or <u>browse files</u> from your device</>}</span>
              <small>MP4, MOV, MKV, WEBM</small>
              <span className="corner corner-tl" /><span className="corner corner-br" />
            </button>
            <input ref={input} type="file" accept="video/*,.mkv" multiple hidden onChange={e => addFiles(Array.from(e.target.files || []))} />
            <p className="card-footnote"><span className="status-dot" /> Your footage stays yours. Always.</p>
          </article>
          <article className="source-card">
            <div className="card-heading"><h2>Paste Youtube/Twitch Link Here</h2><span className="tiny-tag">ONLINE</span></div>
            <div className="link-zone">
              <div className="platforms"><span><Icon name="film" size={16} /> YOUTUBE</span><span className="platform-slash">/</span><span>TWITCH</span></div>
              <label htmlFor="video-link">Got a link? Drop it in.</label>
              <div className="link-input"><Icon name="link" size={19} /><input id="video-link" type="url" placeholder="https://youtube.com/watch?v=..." value={link} onChange={e => { setLink(e.target.value); setMessage('') }} /><span className="input-arrow"><Icon name="arrow" size={18} /></span></div>
              <p>Long streams. Big moments. We'll find the gems.</p>
            </div>
            <p className="card-footnote">FROM FULL-LENGTH TO HIGHLIGHT-REEL.</p>
          </article>
        </section>

        <div className="section-divider settings-divider"><span>02 / MAKE IT YOURS</span><span>YOU CALL THE SHOTS</span></div>
        <section className="settings-panel" aria-labelledby="settings-title">
          <div className="settings-intro"><h2 id="settings-title">Clip Settings</h2><p>The right cut.<br />Every time.</p><span className="settings-mark" aria-hidden="true">↗</span></div>
          <div className="sliders">
            <div className="range-group"><div className="control-label"><label htmlFor="duration">Duration of Clips</label><output htmlFor="duration">{duration}<small> SEC</small></output></div>
              <div className="range-track"><img src={`${assetPathPrefix}/3ceed.svg`} alt="" /><input id="duration" type="range" min="5" max="180" value={duration} onChange={e => setDuration(+e.target.value)} /></div>
              <div className="range-ticks"><span>0s</span><span>90s</span><span>180s</span></div>
            </div>
            <div className="range-group"><div className="control-label"><label htmlFor="count">Number of Clips</label><output htmlFor="count">{count}<small> CLIPS</small></output></div>
              <div className="range-track"><img src={`${assetPathPrefix}/3ceed.svg`} alt="" /><input id="count" type="range" min="1" max="30" value={count} onChange={e => setCount(+e.target.value)} /></div>
              <div className="range-ticks"><span>0</span><span>15</span><span>30</span></div>
            </div>
          </div>
          <fieldset className="quality"><legend>Quality</legend><div className="quality-options">{['1080p', '720p', '480p', '360p'].map(item => <label key={item} className={quality === item ? 'selected' : ''}><input type="radio" name="quality" value={item} checked={quality === item} onChange={() => setQuality(item)} /><span>{item}</span>{item === '1080p' && <small>FULL HD</small>}</label>)}</div><p>Good footage deserves<br />a sharp finish.</p></fieldset>
        </section>

        <div className="action-row"><div className="action-copy"><span className="mini-star" aria-hidden="true">✳</span><div><strong>Find the moments that matter.</strong><p>Less scrolling. More creating.</p></div></div><button className="analyze-button" onClick={analyze}><img src={`${assetPathPrefix}/f9370.svg`} alt="" /><span>Analyze</span><Icon name="arrow" size={23} /></button></div>
        {message && <div role="status" className="feedback">{message}<button onClick={() => setMessage('')} aria-label="Dismiss message">×</button></div>}
        <footer><span>CLIPFORGE <span className="footer-slash">/</span> MADE FOR CREATORS, NOT COMPLICATIONS.</span><span>TAKE THE RAW. MAKE IT GOLD.</span></footer>
      </main>
    </div>
  )
}
